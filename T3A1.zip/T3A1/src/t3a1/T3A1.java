
package t3a1;
import java.util.Scanner;
/**
 *
 * @author esmer
 */
public class T3A1 {

    
    public static void main(String[] args) {
        procesar();
        
    }
  public static void procesar(){
  Scanner obj=new Scanner(System.in);
  Calificaciones calificaciones = new Calificaciones();
  
      System.out.printf("Nombre: ");
      String nombre = obj.nextLine();
      calificaciones.setNombre(nombre);
      
      System.out.printf("Apellido Paterno: ");
      String apellidoPaterno = obj.nextLine();
      calificaciones.setApellidoPaterno(apellidoPaterno);
      
      System.out.printf("Apellido Materno: ");
      String apellidoMaterno = obj.nextLine();
      calificaciones.setApellidoMaterno(apellidoMaterno);
      
      System.out.printf("Grupo: ");
      String grupo = obj.nextLine();
      calificaciones.setGrupo(grupo);
      
      System.out.printf("Carrera: ");
      String carrera = obj.nextLine();
      calificaciones.setCarrera(carrera);
      
      System.out.printf("Asignatura 1: ");
      String nombreAsignatura = obj.nextLine();
      calificaciones.setNombreAsignatura(nombreAsignatura);
      
      System.out.printf("Asignatura 2: ");
      String nombreAsignatura2 = obj.nextLine();
      calificaciones.setNombreAsignatura2(nombreAsignatura2);
      
      System.out.printf("Calificación de la asignatura " + nombreAsignatura + ":");
      float calificacion = obj.nextFloat();
      calificaciones.setCalificacion(calificacion);
      
      System.out.printf("Calificación de la asignatura " + nombreAsignatura2 + ":");
      float calificacion2 = obj.nextFloat();
      calificaciones.setCalificacion2(calificacion2);
       
      calificaciones.getPromedio();
      

      System.out.println(calificaciones.toString());
  }  
}
