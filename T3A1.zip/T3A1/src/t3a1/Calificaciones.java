
package t3a1;
import java.util.Scanner;
/**
 *
 * @author esmer
 */
public class Calificaciones {
    private String nombre;
    private String apellidoPaterno;
    private String apellidoMaterno; 
    private String grupo;
    private String carrera;
    private String nombreAsignatura;
    private float calificacion;
    private String nombreAsignatura2;
    private float calificacion2;
    private double promedio;

//metodo constructor vacio
    public Calificaciones() {
    }
//metodo constructor parametrizado

    public Calificaciones(String nombre, String apellidoPaterno, String apellidoMaterno, String grupo, 
            String carrera, String nombreAsignatura, String nombreAsignatura2, float calificacion, float calificacion2, double promedio) {
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.grupo = grupo;
        this.carrera = carrera;
        this.nombreAsignatura = nombreAsignatura;
        this.calificacion = calificacion;
        this.nombreAsignatura2 = nombreAsignatura2;
        this.calificacion2 = calificacion2;
        this.promedio = promedio;
    }
//toString
    @Override
    public String toString() {
        return "\nEstudiante:  " + nombre + " " + apellidoPaterno + " " + apellidoMaterno + 
                "\nGrupo: " + grupo + "  Carrera: " + carrera + 
                "\nAsignaturas:               Calificaciones:\n" + 
                nombreAsignatura + "                 " + calificacion + 
                "\n"+nombreAsignatura2 + "                 " + calificacion2 +
                "\nPromedio:                 " + promedio;
    }
    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public String getNombreAsignatura() {
        return nombreAsignatura;
    }

    public void setNombreAsignatura(String nombreAsignatura) {
        this.nombreAsignatura = nombreAsignatura;
    }

    public float getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(float calificacion) {
        this.calificacion = calificacion;
    }
    public String getNombreAsignatura2() {
        return nombreAsignatura2;
    }

    public void setNombreAsignatura2(String nombreAsignatura2) {
        this.nombreAsignatura2 = nombreAsignatura2;
    }

    public float getCalificacion2() {
        return calificacion2;
    }

    public void setCalificacion2(float calificacion2) {
        this.calificacion2 = calificacion2;
    }

    public double getPromedio() {
        promedio =(calificacion+calificacion2)/2;
        return promedio;
    }

    public void setPromedio(double promedio) {
        this.promedio = promedio;
    }


    
}
